﻿namespace Glamping_Addventure.Models.View
{
    public class VMPaquete
    {
        public string NombrePaquete { get; set; }
        public int Cantidad { get; set; }
    }
}
